﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UdemyIdentity.Context
{
    public class AppUser : IdentityUser<int>
    {
        public string PictureUrl { get; set; }
        //3NF YE AYKIRI
        public string Gender { get; set; }

        public string Name { get; set; }
        public string SurName { get; set; }
    }
}
